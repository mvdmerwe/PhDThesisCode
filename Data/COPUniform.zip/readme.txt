Data file structure:
X, Y, r, v

X,Y are the location coordinates
r is the protection requirement
v is the value of the location